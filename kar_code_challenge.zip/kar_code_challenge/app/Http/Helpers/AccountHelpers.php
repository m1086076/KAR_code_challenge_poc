<?php
namespace App\Http\Helpers;
use App\Models\Account;
    
class AccountHelpers
{
    public function checkAccount($account_no,$account_holder_name=null,$account_type=null)
    {
        if($account_no!=null && $account_holder_name!=null && $account_type!=null){
            $getAccount = Account::where('account_number','=',$account_no)->where('account_holder_name','like',$account_holder_name)->where('account_type','=',$account_type)->first();
        }
        else if($account_no!=null && $account_holder_name==null && $account_type==null){
            $getAccount = Account::where('account_number','=',$account_no)->first();
        }

        if(isset($getAccount->id)){
            return $getAccount->id;
        }
        else{
            return false;
        }
    }

     
    public static function instance()
    {
        return new AccountHelpers();
    }
}