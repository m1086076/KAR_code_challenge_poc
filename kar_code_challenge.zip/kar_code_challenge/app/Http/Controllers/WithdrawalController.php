<?php

namespace App\Http\Controllers;

use App\Http\Controllers\RequestsValidation\WithdrawalRequestValidation;
use App\Models\Account;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;

class WithdrawalController extends Controller
{
    function withdraw_amount(WithdrawalRequestValidation $request)
    {  
        $id = \App\Http\Helpers\AccountHelpers::instance()->checkAccount($request->account_number,$request->account_holder_name,$request->account_type);

        if($id){
            DB::beginTransaction();
            try {
    
    
                $account = Account::find($id);
                if($account->balance<$request->withdraw_amount){
                    return ['Failled' => false,'message' => 'Insufficient fund'];
                }
                if($account->investment_account_type=='Indivisual' && $request->withdraw_amount>500){
                    return ['Failled' => false,'message' => 'You can\'t withdraw more than 500$'];
                }
                $new_balance = floatval($account->balance)-floatval($request->withdraw_amount);
                $account->balance = $new_balance;
                $account->save();

                $transactions =  new Transaction;
                $transactions->account_id = $id;
                $transactions->transaction_type = 2;
                $transactions->amount = floatval($request->withdraw_amount);
                $transactions->remarks = $request->remark??'NA';
                $transactions->save();
                DB::commit();
                return ["success" => "Your account XXXXXXXXX".substr ($request->account_number, -4)." has been debited ".floatval($request->withdraw_amount)."$, available balance is ".$new_balance."$"];
            } catch (\Throwable $th) {
               DB::rollBack();
                return ['success' => false,'message' => 'Somthing went wrong'];
            }
        }
        else{
            return ['success' => false,'message' => 'Invalid account details'];
        }
    }
}
