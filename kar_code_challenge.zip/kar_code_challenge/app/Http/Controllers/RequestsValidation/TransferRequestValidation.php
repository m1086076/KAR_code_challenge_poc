<?php

namespace App\Http\Controllers\RequestsValidation;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;

class TransferRequestValidation extends FormRequest
{
    public function rules()
    {
        return [
            'dr_account_number' => 'required|min:16|max:16',
            'transfer_amount' => 'required|integer|between: 1,9999999999.99',
            'dr_account_holder_name' => 'required',
            'dr_account_type' => 'required|in:Reviewing,Investment',

            'cr_account_number' => 'required|min:16|max:16',
            'cr_account_holder_name' => 'required',
            'cr_account_type' => 'required|in:Reviewing,Investment',
        ];
    }

    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([

            'success'   => false,
            'message'   => 'Validation errors',
            'data'      => $validator->errors()
        ]));
    }

    public function messages()
    {
        return [
            'dr_account_number.required' => 'Please enter valid account number',
            'transfer_amount.required' => 'Please enter valid amount',
            'dr_account_holder_name.required' => 'Please enter account holder name',
            'dr_account_type.required' => 'Please enter account type',
            
            'cr_account_number.required' => 'Please enter valid beneficiary account number',
            'dr_account_type.required' => 'Please enter beneficiary account type',
            'cr_account_holder_name.required' => 'Please enter beneficiary account holder name',];
    }
}



