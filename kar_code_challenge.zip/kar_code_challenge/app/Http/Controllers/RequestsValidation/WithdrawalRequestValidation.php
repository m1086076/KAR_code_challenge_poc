<?php

namespace App\Http\Controllers\RequestsValidation;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;

class WithdrawalRequestValidation extends FormRequest
{
    public function rules()
    {
        return [
            'account_number' => 'required|min:16|max:16',
            'withdraw_amount' => 'required|integer|between: 1,9999999999.99',
            'account_holder_name' => 'required',
            'account_type' => 'required|in:Reviewing,Investment',
        ];
    }

    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([

            'success'   => false,
            'message'   => 'Validation errors',
            'data'      => $validator->errors()
        ]));
    }

    public function messages()
    {
        return [
            'account_number.required' => 'Please enter valid account number',
            'withdraw_amount.required' => 'Please enter valid amount',
            'account_holder_name.required' => 'Please enter account holder name',
            'account_type.required' => 'Please enter account type'];
    }
}


