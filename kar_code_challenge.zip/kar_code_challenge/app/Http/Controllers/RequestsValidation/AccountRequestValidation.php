<?php

namespace App\Http\Controllers\RequestsValidation;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;

class AccountRequestValidation extends FormRequest
{
    public function rules()
    {
        return [
            'account_number' => 'min:16|max:16',
        ];
    }

    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([

            'success'   => false,
            'message'   => 'Invalid account number',
            'data'      => $validator->errors()
        ]));
    }

    public function messages()
    {
        return [
            'account_number' => 'Please enter valid account number'
        ];
    }
}
