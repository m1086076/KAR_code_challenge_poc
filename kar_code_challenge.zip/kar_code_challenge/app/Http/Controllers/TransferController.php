<?php

namespace App\Http\Controllers;

use App\Http\Controllers\RequestsValidation\TransferRequestValidation;
use App\Models\Account;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;

class TransferController extends Controller
{
    function transfer_amount(TransferRequestValidation $request)
    {  
        $dr_id = \App\Http\Helpers\AccountHelpers::instance()->checkAccount($request->dr_account_number,$request->dr_account_holder_name,$request->dr_account_type);

        $cr_id = \App\Http\Helpers\AccountHelpers::instance()->checkAccount($request->cr_account_number,$request->cr_account_holder_name,$request->cr_account_type);

        if($dr_id && $cr_id){
            DB::beginTransaction();
            try {
    
    
                $dr_account = Account::find($dr_id);
                $cr_account = Account::find($cr_id);
                if($dr_account->balance<$request->transfer_amount){
                    return ['Failled' => false,'message' => 'Insufficient fund'];
                }
                if($dr_account->investment_account_type=='Indivisual' && $request->transfer_amount>500){
                    return ['Failled' => false,'message' => 'You can\'t transfer more than 500$'];
                }
                if($dr_account->account_number===$cr_account->account_number){
                    return ['Failled' => false,'message' => 'You can\'t transfer in same account'];
                }
                $dr_new_balance = floatval($dr_account->balance)-floatval($request->transfer_amount);
                $dr_account->balance = $dr_new_balance;
                $dr_account->save();

                $cr_new_balance = floatval($cr_account->balance)+floatval($request->transfer_amount);
                $cr_account->balance = $cr_new_balance;
                $cr_account->save();

                $dr_transactions =  new Transaction;
                $dr_transactions->account_id = $dr_id;
                $dr_transactions->transaction_type = 3;
                $dr_transactions->amount = floatval($request->transfer_amount);
                $dr_transactions->remarks = 'Transfer to account no : '.$cr_account->account_number;
                $dr_transactions->save();

                $cr_transactions =  new Transaction;
                $cr_transactions->account_id = $cr_id;
                $cr_transactions->transaction_type = 1;
                $cr_transactions->amount = floatval($request->transfer_amount);
                $cr_transactions->remarks = 'Received from account no : '.$dr_account->account_number;
                $cr_transactions->save();

                DB::commit();
                return ["success" => "Transation successfully completed"];
            } catch (\Throwable $th) {
               DB::rollBack();
                return ['success' => false,'message' => 'Somthing went wrong'];
            }
        }
        else{
            return ['success' => false,'message' => 'Invalid account details'];
        }
    }
}
