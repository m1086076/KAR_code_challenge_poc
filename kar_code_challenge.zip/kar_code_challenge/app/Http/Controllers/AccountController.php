<?php

namespace App\Http\Controllers;

use App\Http\Controllers\RequestsValidation\AccountRequestValidation;
use App\Models\Account;

class AccountController extends Controller
{
    function get_account(AccountRequestValidation $request)
    {   
        return $request->account_number?Account::where('account_number','=',$request->account_number)->get():Account::All();
    }
}
