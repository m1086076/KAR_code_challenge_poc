<?php

namespace App\Http\Controllers;

use App\Http\Controllers\RequestsValidation\DepositRequestValidation;
use App\Models\Account;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;

class DepositController extends Controller
{
    function deposit_amount(DepositRequestValidation $request)
    {  
        $id = \App\Http\Helpers\AccountHelpers::instance()->checkAccount($request->account_number);
        if($id){
            DB::beginTransaction();
            try {
                $account = Account::find($id);
                $new_balance = floatval($account->balance)+floatval($request->deposit_amount);
                $account->balance = $new_balance;
                $account->save();

                $transactions =  new Transaction;
                $transactions->account_id = $id;
                $transactions->transaction_type = 1;
                $transactions->amount = floatval($request->deposit_amount);
                $transactions->remarks = $request->remark;
                $transactions->save();
                DB::commit();
                return ["success" => floatval($request->deposit_amount)."$ has been successfully credited in your account : XXXXXXXXX".substr ($request->account_number, -4)." current balance is ".$new_balance."$"];
            } catch (\Throwable $th) {
               DB::rollBack();
                return ['success' => false,'message' => 'Somthing went wrong'];
            }
        }
        else{
            return ['success' => false,'message' => 'Invalid account details', 'data' => $request];
        }
    }

}